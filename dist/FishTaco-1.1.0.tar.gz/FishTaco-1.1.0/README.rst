FishTaco: Functional Shifts Taxonomic Contributors
==================================================

The official FishTaco source code repository. For details on FishTaco, see http://borenstein-lab.github.io/fishtaco/.

FishTaco is a metagenomic computational framework, aiming to identify the taxa that are driving the functional shifts
we observe in microbiomes of different individuals or disease states.

For FishTaco announcements and questions, including notification of new releases, you can visit the `FiShTaCo users forum <https://groups.google.com/forum/#!forum/fishtaco-users>`_.

